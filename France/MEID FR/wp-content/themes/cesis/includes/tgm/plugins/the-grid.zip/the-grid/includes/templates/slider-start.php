<?php
/**
 * @package   The_Grid
 * @author    Themeone <themeone.master@gmail.com>
 * @copyright 2015 Themeone
 */

// Exit if accessed directly
if (!defined('ABSPATH')) { 
	exit;
}

$slider_start  = '<!-- The Grid Slider Wrapper Start -->';
$slider_start .= '<div class="tg-grid-slider">';

echo $slider_start;