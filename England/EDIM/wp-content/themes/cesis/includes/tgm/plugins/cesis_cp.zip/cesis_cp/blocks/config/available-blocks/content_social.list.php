<?php
////////////////////
//  Template 01  //
//////////////////
$data = array(
	'group'        => 'content_social',
	'id'           => '1',
	'img'          => '01.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row_content_no_spaces"][vc_column width="1/6"][vc_raw_html]JTNDc3R5bGUlM0UuY2VzaXNfZnVsbF93X2ljb24lMjAuY2VzaXNfaWNvbl9zaGFwZSUyMCU3QiUwQSUyMCUyMCUyMCUyMHdpZHRoJTNBJTIwMTAwJTI1JTIxaW1wb3J0YW50JTNCJTBBJTdEJTBBJTNDJTJGc3R5bGUlM0U=[/vc_raw_html][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-facebook2" el_class="cesis_full_w_icon"][/vc_column][vc_column width="1/6" css=".vc_custom_1507097433159{border-right-width: 1px !important;border-left-width: 1px !important;border-left-color: #e0e0e0 !important;border-left-style: solid !important;border-right-color: #e0e0e0 !important;border-right-style: solid !important;}"][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-twitter2" el_class="cesis_full_w_icon"][/vc_column][vc_column width="1/6"][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-behance" el_class="cesis_full_w_icon"][/vc_column][vc_column width="1/6" css=".vc_custom_1507097469779{border-right-width: 1px !important;border-left-width: 1px !important;border-left-color: #e0e0e0 !important;border-left-style: solid !important;border-right-color: #e0e0e0 !important;border-right-style: solid !important;}"][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-dribbble2" el_class="cesis_full_w_icon"][/vc_column][vc_column width="1/6"][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-google-plus" el_class="cesis_full_w_icon"][/vc_column][vc_column width="1/6" css=".vc_custom_1507097536882{border-left-width: 1px !important;border-left-color: #e0e0e0 !important;border-left-style: solid !important;}"][cesis_icon i_size="30" use_shape="yes" shape="squared" i_bg_size="220" icon_color="#c6c6c6" icon_bg_color="#f4f4f4" h_icon_color="#ffffff" h_icon_bg_color="#1769ff" icon="fa-wordpress2" el_class="cesis_full_w_icon"][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );
