<?php

return array(

	array(
		'id'   => 'sliders',
		'name' => 'Sliders / Banners'
	),

	array(
		'id'   => 'content_about',
		'name' => 'Content → About'
	),

	array(
		'id'   => 'content_feature',
		'name' => 'Content → Feature'
	),

	array(
		'id'   => 'content_blog',
		'name' => 'Content → Blog'
	),

	array(
		'id'   => 'content_portfolio',
		'name' => 'Content → Portfolio'
	),

	array(
		'id'   => 'content_staff',
		'name' => 'Content → Staff'
	),

	array(
		'id'   => 'content_apps',
		'name' => 'Content → Apps'
	),

	array(
		'id'   => 'content_testimonials',
		'name' => 'Content → Testimonials'
	),

	array(
		'id'   => 'content_social',
		'name' => 'Content → Social'
	),

	array(
		'id'   => 'content_contacts',
		'name' => 'Content → Contact'
	),

	array(
		'id'   => 'content_pricing_tables',
		'name' => 'Content → Price Tables'
	),

	array(
		'id'   => 'content_timeline',
		'name' => 'Content → Timeline'
	),

	array(
		'id'   => 'content_cta',
		'name' => 'Content → Call to Action'
	),

	array(
		'id'   => 'footers',
		'name' => 'Footers'
	),

);
