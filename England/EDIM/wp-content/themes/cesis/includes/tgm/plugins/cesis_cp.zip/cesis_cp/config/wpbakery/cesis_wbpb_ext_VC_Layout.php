<?php

class cesis_wbpb_ext_VC_Layout
{
	function __construct()
	{

	}

	/**
	 * @version 1.0.0
	 * Config Navs
	 */
	public
	function config()
	{
	}

	/**
	 * @version 1.0.0
	 * Load Function
	 */
	public
	function load()
	{
	}
}
