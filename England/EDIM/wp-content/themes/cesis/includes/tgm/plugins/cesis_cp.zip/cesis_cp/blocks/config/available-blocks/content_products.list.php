<?php
////////////////////
//  Template 01  //
//////////////////
$data = array(
	'group'        => 'content_products',
	'id'           => '1',
	'img'          => '01.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT

CONTENT
);
$this->add__block( $data );
