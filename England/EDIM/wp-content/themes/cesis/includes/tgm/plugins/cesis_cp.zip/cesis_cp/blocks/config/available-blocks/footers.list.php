<?php
////////////////////
//  Template 01  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '1',
	'img'          => '01.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row" css=".vc_custom_1525460884554{border-bottom-width: 1px !important;padding-top: 50px !important;padding-bottom: 50px !important;background-color: #1d222b !important;border-bottom-color: #262c38 !important;border-bottom-style: solid !important;}"][vc_column][vc_single_image image="10252" img_size="90x22" alignment="center" css=".vc_custom_1525461400727{margin-bottom: 0px !important;}"][/vc_column][/vc_row][vc_row full_width="stretch_row" css=".vc_custom_1526048250676{padding-top: 30px !important;padding-bottom: 30px !important;background-color: #1d222b !important;}"][vc_column][cesis_share_shortcode link="https://themeforest.net/user/tranmautritam?ref=tranmautritam" position="cesis_share_center" color_type="custom" facebook="yes" twitter="yes" google="yes" linkedin="yes" xing="yes" vk="yes" icon_color="#aeb7c1" icon_h_color="#ffffff" css_animation="none"][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 02  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '2',
	'img'          => '02.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row_content" content_placement="middle" css=".vc_custom_1525445109181{padding-top: 40px !important;padding-bottom: 40px !important;background-color: #1d222b !important;}"][vc_column width="1/4" css=".vc_custom_1513222105177{padding-top: 40px !important;padding-bottom: 40px !important;}"][vc_single_image image="10252" img_size="90x22" alignment="center" css=".vc_custom_1525450668866{margin-bottom: 20px !important;}"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445593034{margin-bottom: 15px !important;}"]</p>
<p style="text-align: center;">Made with love by Tranmautritam<br />
© 2018. All rights reserved.</p>
<p>[/vc_column_text][cesis_share_shortcode link="https://themeforest.net/user/tranmautritam?ref=tranmautritam" position="cesis_share_center" space="15" color_type="custom" facebook="yes" twitter="yes" google="yes" mail="yes" icon_color="#ffffff" css_animation="fadeInUp"][/vc_column][vc_column width="1/4" css=".vc_custom_1521025137671{padding-top: 40px !important;padding-bottom: 40px !important;}" offset="vc_hidden-sm vc_hidden-xs"][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" heading_font="main_font" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22USA%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445452609{margin-bottom: 60px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22FRANCE%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445480474{margin-bottom: 0px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][/vc_column][vc_column width="1/4" css=".vc_custom_1521025146270{padding-top: 40px !important;padding-bottom: 40px !important;}" offset="vc_hidden-sm vc_hidden-xs"][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22UNITED%20KINGDOM%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445452609{margin-bottom: 60px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22AUSTRALIA%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445480474{margin-bottom: 0px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][/vc_column][vc_column width="1/4" css=".vc_custom_1521025155479{padding-top: 40px !important;padding-bottom: 40px !important;}" offset="vc_hidden-sm vc_hidden-xs"][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22VIETNAM%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445452609{margin-bottom: 60px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][cesis_icon_list margin_bottom="18" heading_color="#ffffff" h_heading_color="#ffffff" text_color="#ffffff" icon_color="#ffffff" h_icon_color="#ffffff" h_f_size="11px" h_l_height="14px" h_l_spacing="1" values="%5B%7B%22icon%22%3A%22fa-pin%22%2C%22heading%22%3A%22JAPAN%22%7D%5D"][vc_column_text font_size="14px" line_height="24px" font_color="#aeb7c1" css=".vc_custom_1525445480474{margin-bottom: 0px !important;}"]Cesis Agency<br />
1 Infinite Loop<br />
Cupertino, CA 95014<br />
(408) 996–1010[/vc_column_text][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 03  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '3',
	'img'          => '03.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row" css=".vc_custom_1525620163660{padding-top: 80px !important;background-color: #1d222b !important;}"][vc_column][vc_single_image image="10252" img_size="90x22" alignment="center" css=".vc_custom_1525620308581{margin-bottom: 30px !important;}"][vc_row_inner][vc_column_inner width="1/3" css=".vc_custom_1513232252393{padding-top: 40px !important;padding-bottom: 40px !important;}"][cesis_icon i_size="16" margin_bottom="27" icon_color="#aeb7c1" h_icon_color="#aeb7c1" icon="fa-mail"][vc_custom_heading text="email" font_container="tag:h3|font_size:14|text_align:center|color:%23ffffff|line_height:16px" text_transform="cesis_text_transform_uppercase" letter_spacing="2" use_theme_fonts="yes" css=".vc_custom_1513231973371{margin-bottom: 14px !important;}"][cesis_icon i_size="5" margin_bottom="12" icon_color="#69d2e7" h_icon_color="#69d2e7" icon="fa-remove4"][vc_column_text font_color="#ffffff" css=".vc_custom_1513232367551{margin-bottom: 0px !important;}"]
<p style="text-align: center;">cesis.co@gmail.com</p>
[/vc_column_text][/vc_column_inner][vc_column_inner width="1/3" css=".vc_custom_1513232265764{padding-top: 40px !important;padding-bottom: 40px !important;}"][cesis_icon i_size="16" margin_bottom="27" icon_color="#aeb7c1" h_icon_color="#aeb7c1" icon="fa-phone2"][vc_custom_heading text="call" font_container="tag:h3|font_size:14|text_align:center|color:%23ffffff|line_height:16px" text_transform="cesis_text_transform_uppercase" letter_spacing="2" use_theme_fonts="yes" css=".vc_custom_1513232042161{margin-bottom: 14px !important;}"][cesis_line_divider height="1" width="20" color="#ffffff" margin_top="20" margin_bottom="20"][vc_column_text font_color="#ffffff" css=".vc_custom_1513232378708{margin-bottom: 0px !important;}"]
<p style="text-align: center;">+84 935 815 989</p>
<p>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/3" css=".vc_custom_1513232280754{padding-top: 40px !important;padding-bottom: 40px !important;}"][cesis_icon i_size="16" margin_bottom="27" icon_color="#aeb7c1" h_icon_color="#aeb7c1" icon="fa-pin"][vc_custom_heading text="find us" font_container="tag:h3|font_size:14|text_align:center|color:%23ffffff|line_height:16px" text_transform="cesis_text_transform_uppercase" letter_spacing="2" use_theme_fonts="yes" css=".vc_custom_1513232078847{margin-bottom: 14px !important;}"][cesis_icon i_size="5" margin_bottom="12" icon_color="#69d2e7" h_icon_color="#69d2e7" icon="fa-remove4"][vc_column_text font_color="#ffffff" css=".vc_custom_1513232388694{margin-bottom: 0px !important;}"]
<p style="text-align: center;">4th Highland, Hope Boulevard</p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1525620332987{border-top-width: 1px !important;padding-top: 40px !important;padding-bottom: 40px !important;border-top-color: #262c38 !important;border-top-style: solid !important;}"][vc_column_inner][cesis_share_shortcode link="https://themeforest.net/user/tranmautritam?ref=tranmautritam" size="cesis_share_big" position="cesis_share_center" color_type="custom" facebook="yes" twitter="yes" google="yes" linkedin="yes" xing="yes" vk="yes" mail="yes" icon_color="#aeb7c1" icon_h_color="#ffffff"][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 04  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '4',
	'img'          => '04.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row" css=".vc_custom_1507792729282{padding-top: 60px !important;padding-bottom: 60px !important;background-color: #ffffff !important;}"][vc_column width="1/3" css=".vc_custom_1507792529209{padding-top: 20px !important;padding-bottom: 20px !important;}"][vc_single_image image="7464" img_size="150*50" css=".vc_custom_1507792820525{margin-bottom: 30px !important;}"][vc_column_text css=".vc_custom_1507792828831{margin-bottom: 25px !important;}"]Cesis has so many features it’s incredible and the best part of it is that it’s incredibly easy to use, everyone can build website now.[/vc_column_text][cesis_share_shortcode type="cesis_share_rounded" color_type="cesis_share_grey" facebook="yes" twitter="yes" google="yes" linkedin="yes"][/vc_column][vc_column width="1/3"][vc_custom_heading text="Helpful Links" font_container="tag:h4|font_size:18|text_align:left|line_height:24px" google_fonts="font_family:Playfair%20Display%3Aregular%2Citalic%2C700%2C700italic%2C900%2C900italic|font_style:700%20bold%20regular%3A700%3Anormal"][vc_row_inner][vc_column_inner width="1/2" css=".vc_custom_1507795882005{padding-top: 10px !important;padding-bottom: 10px !important;}"][cesis_icon_list space="15" heading_color="#666666" h_heading_color="#69d2e7" heading_font="main_font" h_f_weight="400" h_t_transform="none" values="%5B%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Themeforest%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Documentation%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Support%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Download%22%7D%5D"][/vc_column_inner][vc_column_inner width="1/2" css=".vc_custom_1507795877957{padding-top: 10px !important;padding-bottom: 10px !important;}"][cesis_icon_list space="15" heading_color="#666666" h_heading_color="#69d2e7" heading_font="main_font" h_f_weight="400" h_t_transform="none" values="%5B%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Themeforest%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Documentation%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Support%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Download%22%7D%5D"][/vc_column_inner][/vc_row_inner][/vc_column][vc_column width="1/3"][vc_custom_heading text="Newsletter" font_container="tag:h4|font_size:18|text_align:left|line_height:24px" google_fonts="font_family:Playfair%20Display%3Aregular%2Citalic%2C700%2C700italic%2C900%2C900italic|font_style:700%20bold%20regular%3A700%3Anormal" css=".vc_custom_1507801015349{margin-bottom: 30px !important;}"][cesis_cf7 contact_id="7717" f_radius="4" button_type="custom" btn_width="cesis_cf7_fw_btn" btn_radius="4" f_style="custom" f_text_color="#666666" f_place_holder="#666666" f_bg_color="#f4f4f4" f_b_color="#f4f4f4" button_text_color="#ffffff" button_bg_color="#486dcb" button_border_color="#486dcb" button_h_text_color="#ffffff" button_h_bg_color="#333333" button_h_border_color="#333333" button_google_fonts="font_family:Open%20Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic|font_style:700%20bold%20regular%3A700%3Anormal" button_l_spacing="1" el_class="cesis_align_a_center"][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 05  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '5',
	'img'          => '05.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row_content_no_spaces" css=".vc_custom_1527849306264{padding-top: 5vw !important;padding-right: 5vw !important;padding-left: 5vw !important;background-color: #ffffff !important;}"][vc_column][vc_row_inner equal_height="yes" content_placement="middle"][vc_column_inner width="2/3" css=".vc_custom_1527870565455{padding-bottom: 5vw !important;}" offset="vc_hidden-sm vc_hidden-xs"][vc_single_image image="103" img_size="full" css=".vc_custom_1527849362808{margin-bottom: 40px !important;}" el_class="cesis_retina_img"][vc_column_text css=".vc_custom_1527856193968{margin-bottom: 0px !important;}"]© 2015 - 2018 Tranmautritam Team. Cesis Creative demo for Cesis WordPress Theme.[/vc_column_text][/vc_column_inner][vc_column_inner width="1/3" css=".vc_custom_1527870559312{padding-bottom: 5vw !important;}" offset="vc_hidden-sm vc_hidden-xs"][vc_custom_heading text="Connect With Us" font_container="tag:h4|font_size:18px|text_align:right|line_height:30px" letter_spacing="-0.7" use_theme_fonts="yes" css=".vc_custom_1527857136415{margin-bottom: 40px !important;}"][cesis_icon i_size="20" position="i_float_right" margin_left="30" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeIn" delay="400" icon_color="#262b40" icon="fa-behance"][cesis_icon i_size="20" position="i_float_right" margin_left="30" margin_right="" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeIn" delay="300" icon_color="#262b40" icon="fa-dribbble"][cesis_icon i_size="20" position="i_float_right" margin_left="30" margin_right="" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeIn" delay="200" icon_color="#262b40" icon="fa-google-plus"][cesis_icon i_size="20" position="i_float_right" margin_left="30" margin_right="" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeIn" delay="100" icon_color="#262b40" icon="fa-twitter"][cesis_icon i_size="20" position="i_float_right" margin_left="30" margin_right="" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeIn" icon_color="#262b40" icon="fa-facebook"][/vc_column_inner][/vc_row_inner][vc_row_inner][vc_column_inner css=".vc_custom_1527870642752{padding-bottom: 5vw !important;}" offset="vc_hidden-lg vc_hidden-md"][vc_single_image image="103" img_size="full" alignment="center" css=".vc_custom_1527870579847{margin-bottom: 40px !important;}" el_class="cesis_retina_img"][vc_column_text css=".vc_custom_1527870618136{margin-bottom: 0px !important;}"]
<p style="text-align: center;">© 2015 - 2018 Tranmautritam Team. Cesis Creative demo for Cesis WordPress Theme.</p>
[/vc_column_text][/vc_column_inner][/vc_row_inner][cesis_line_divider height="9" width="" color="#14171d"][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 06  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '6',
	'img'          => '06.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row" min_height="535" content_placement="middle" css=".vc_custom_1507791077468{padding-top: 80px !important;padding-bottom: 80px !important;background: #222222 url(https://cesis.co/wp-content/uploads/2017/10/footer-1x.jpg?id=7711) !important;background-position: center !important;background-repeat: no-repeat !important;background-size: cover !important;}"][vc_column][vc_row_inner][vc_column_inner width="1/4" css=".vc_custom_1507790375829{padding-top: 20px !important;padding-bottom: 20px !important;}"][cesis_icon_list space="15" target="_blank" heading_color="#9ca3b1" h_heading_color="#ffffff" h_f_weight="600" h_l_spacing="1" values="%5B%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Themeforest%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Documentation%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Support%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Download%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Envato%20Marketplace%22%7D%5D"][/vc_column_inner][vc_column_inner width="1/4" css=".vc_custom_1507790382057{padding-top: 20px !important;padding-bottom: 20px !important;}"][cesis_icon_list space="15" target="_blank" heading_color="#9ca3b1" h_heading_color="#ffffff" h_f_weight="600" h_l_spacing="1" values="%5B%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Demos%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Features%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22PSD%20templates%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22WordPress%20theme%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22Site%20templates%22%7D%5D"][/vc_column_inner][vc_column_inner width="1/4" css=".vc_custom_1507790387487{padding-top: 20px !important;padding-bottom: 20px !important;}"][cesis_icon_list space="15" target="_blank" heading_color="#9ca3b1" h_heading_color="#ffffff" h_f_weight="600" h_l_spacing="1" values="%5B%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22home%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22about%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22blog%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22portfolio%22%7D%2C%7B%22link%22%3A%22%23%22%2C%22heading%22%3A%22contact%22%7D%5D"][/vc_column_inner][vc_column_inner width="1/4" css=".vc_custom_1507790392540{padding-bottom: 20px !important;}"][cesis_cf7 contact_id="7558" f_space="cesis_cf7_big" button_type="custom" btn_size="cesis_cf7_medium_btn" btn_width="cesis_cf7_fw_btn" btn_radius="100" btn_top_space="9" f_style="custom" f_text_color="#9ca3b1" f_place_holder="#9ca3b1" f_bg_color="rgba(255,255,255,0)" f_b_color="rgba(156,163,177,0.21)" button_text_color="#9ca3b1" button_bg_color="rgba(255,255,255,0)" button_border_color="#ffffff" button_h_text_color="#222222" button_h_bg_color="#ffffff" button_h_border_color="#ffffff" button_google_fonts="font_family:Open%20Sans%3A300%2C300italic%2Cregular%2Citalic%2C600%2C600italic%2C700%2C700italic%2C800%2C800italic|font_style:700%20bold%20regular%3A700%3Anormal" button_f_size="12px" button_l_spacing="1" el_class="cesis_agency_cf7 "][/vc_column_inner][/vc_row_inner][cesis_icon_paragraph i_choice="image" image="7714" image_size="26" heading="" heading_space="0" text="Cesis Theme © 2017 • Made with love by the tranmautritam's team." text_space="0" text_color="#666666"][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );

////////////////////
//  Template 07  //
//////////////////
$data = array(
	'group'        => 'footers',
	'id'           => '7',
	'img'          => '07.jpg',
	'custom_class' => '',
	'content'      => <<<CONTENT
[vc_row full_width="stretch_row_content" css=".vc_custom_1528632648745{margin-bottom: 0px !important;padding-top: 80px !important;padding-right: 5vw !important;padding-bottom: 0px !important;padding-left: 5vw !important;background-color: #ffffff !important;}"][vc_column][vc_row_inner][vc_column_inner width="1/3" css=".vc_custom_1528632448068{padding-bottom: 40px !important;}"][vc_single_image image="28" img_size="full" css=".vc_custom_1528630642609{margin-bottom: 31px !important;}" el_class="cesis_retina_img"][vc_column_text]You want to change the header height or width, menu style or logo position? Everything is possible with Cesis and everything can be done directly live using the WordPress customizer.[/vc_column_text][cesis_icon i_size="16" use_shape="yes" i_bg_size="30" position="i_float_left" margin_right="10" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeInUp" icon_color="#ffffff" icon_bg_color="#5690ce" icon_border_color="#5690ce" icon="fa-facebook"][cesis_icon i_size="16" use_shape="yes" i_bg_size="30" position="i_float_left" margin_right="10" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeInUp" delay="250" icon_color="#ffffff" icon_bg_color="#7bdff2" icon_border_color="#7bdff2" icon="fa-twitter"][cesis_icon i_size="16" use_shape="yes" i_bg_size="30" position="i_float_left" margin_right="10" link="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam" target="_blank" css_animation="fadeInUp" delay="500" icon_color="#ffffff" icon_bg_color="#454951" icon_border_color="#454951" icon="fa-google"][/vc_column_inner][vc_column_inner width="1/6" css=".vc_custom_1528632443052{padding-bottom: 40px !important;}"][vc_custom_heading text="Useful links" font_container="tag:h3|font_size:20|text_align:left|color:%235b5f6b|line_height:22px" use_theme_fonts="yes" css=".vc_custom_1528631815219{padding-bottom: 20px !important;}"][vc_column_text line_height="20px" css=".vc_custom_1528632437758{margin-bottom: 0px !important;}"]<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://themeforest.net/item/cesis-responsive-multipurpose-wordpress-theme/21736436?ref=tranmautritam">Cesis</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="http://themeforest.net/item/thefox-responsive-multipurpose-wordpress-theme/11099136?ref=tranmautritam">Thefox</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://themeforest.net/user/tranmautritam/portfolio?ref=tranmautritam">Portfolio</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://tranmautritam.ticksy.com/">Support</a></span>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6" css=".vc_custom_1528632452262{padding-bottom: 40px !important;}"][vc_custom_heading text="Demos" font_container="tag:h3|font_size:20|text_align:left|color:%235b5f6b|line_height:22px" use_theme_fonts="yes" css=".vc_custom_1528631990334{padding-bottom: 20px !important;}"][vc_column_text line_height="20px" css=".vc_custom_1528632216109{margin-bottom: 0px !important;}"]<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/" target="_blank" rel="noopener">Classic</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/creative-agency/" target="_blank" rel="noopener">Creative Agency</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/photography-home/" target="_blank" rel="noopener">Photography</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/lifestyle-home/" target="_blank" rel="noopener">Lifestyle</a></span>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6" css=".vc_custom_1528632458036{padding-bottom: 40px !important;}"][vc_custom_heading text="Demos" font_container="tag:h3|font_size:20|text_align:left|color:%235b5f6b|line_height:22px" use_theme_fonts="yes" css=".vc_custom_1528631990334{padding-bottom: 20px !important;}"][vc_column_text line_height="20px" css=".vc_custom_1528632121853{margin-bottom: 0px !important;}"]<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/agency-home/" target="_blank" rel="noopener">Agency</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/business-home/" target="_blank" rel="noopener">Business</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/careers-home/" target="_blank" rel="noopener">Careers</a></span>

<span style="color: #8fa1af;"><a style="color: #8fa1af;" href="https://cesis.co/fashion-home/" target="_blank" rel="noopener">Fashion</a></span>[/vc_column_text][/vc_column_inner][vc_column_inner width="1/6" css=".vc_custom_1528632462606{padding-bottom: 40px !important;}"][vc_custom_heading text="Credits" font_container="tag:h3|font_size:20|text_align:left|color:%235b5f6b|line_height:22px" use_theme_fonts="yes" css=".vc_custom_1528632305009{padding-bottom: 20px !important;}"][vc_column_text line_height="20px" css=".vc_custom_1528632328924{margin-bottom: 0px !important;}"]<span style="color: #8fa1af;">Envato</span>

Our Customers

Support Team

Lovely Devs[/vc_column_text][/vc_column_inner][/vc_row_inner][vc_row_inner css=".vc_custom_1528632673437{margin-bottom: 0px !important;padding-top: 40px !important;}"][vc_column_inner][cesis_line_divider height="1" width="" color="#eff7f6"][vc_column_text css=".vc_custom_1528632617787{margin-bottom: 0px !important;padding-top: 40px !important;padding-bottom: 40px !important;}"]© Copyright 2015 - 2018 | Cesis Theme by Tranmautritam | All Rights Reserved | Powered by Photoshop CC 2015.[/vc_column_text][/vc_column_inner][/vc_row_inner][/vc_column][/vc_row]
CONTENT
);
$this->add__block( $data );
